
#include <stdlib.h>        
#include <malloc.h>
#include <assert.h>

#include "hdf5.h"


#define FILE_NAME  "hdf5data.h5"


/* prototypes */
static int write_attr(hid_t loc_id, int rank, hsize_t *dims, const char *attr_name,
                hid_t type_id, void *buf);
static int write_dset( hid_t loc_id, int rank, hsize_t *dims, const char *dset_name,
                   hid_t type_id, void *buf );



/*-------------------------------------------------------------------------
 * Function: write_attr_in
 *
 * Purpose: write attributes in LOC_ID (dataset, group, named datatype) 
 *
 *-------------------------------------------------------------------------
 */

static void write_attr_in(hid_t loc_id, 
																										const char* dset_name, /* for saving reference to dataset*/
																										hid_t file_id)
{
 /* Compound datatype */
	typedef struct s_t 
 {
  char   name[16];
  int    lati;
  int    longi;
  float  pressure;
  double temperature; 
 } s_t;

 typedef enum 
 {
  E_RED,
  E_GREEN
 } e_t;

 hid_t   attr_id;
 hid_t   space_id;  
 hid_t   type_id, type_str_id;  
 herr_t  status;
 int     val, i, j, k, n;
	float   f;
	char    str[20];

	/* create 1D attributes with dimension [2], 2 elements */
 hsize_t    dims[1]={2};
	char       buf1[2][2]= {"ab","de"};        /* string */
 char       buf2[2]= {1,2};                 /* bitfield, opaque */
	s_t        buf3[2] = { {"zero",0,0, 0.0f, 0.0},/* compound */
	{"one",10,10, 1.0f, 10.0}};
 hobj_ref_t buf4[2];                        /* reference */
 hvl_t      buf5[2];                        /* vlen */
 hsize_t    dimarray[1]={3};                /* array dimension */
 int        buf6[2][3]= {{1,2,3},{4,5,6}};  /* array */
	int        buf7[2]= {1,2};                 /* integer */
	float      buf8[2]= {1,2};                 /* float */

	/* create 2D attributes with dimension [3][2], 6 elements */
 hsize_t    dims2[2]={3,2};
	char       buf12[6][2]= {"ab","cd","ef","gh","ij","kl"};         /* string */
 char       buf22[3][2]= {{1,2},{3,4},{5,6}};                     /* bitfield, opaque */
	s_t        buf32[6] = { {"zero",0,0, 0.0f, 0.0},                 /* compound */
	{"one",10,10, 1.0f, 10.0},
	{"two",  20,20, 2.0f, 20.0},
	{"three",30,30, 3.0f, 30.0},
	{"four", 40,40, 4.0f, 40.0},
	{"five", 50,50, 5.0f, 50.0}};
 hobj_ref_t buf42[3][2];                                          /* reference */
 hvl_t      buf52[3][2];                                          /* vlen */
 int        buf62[6][3]= {{1,2,3},{4,5,6},{7,8,9},{10,11,12},{13,14,15},{16,17,18}};  /* array */
	int        buf72[3][2]= {{1,2},{3,4},{5,6}};                     /* integer */
	float      buf82[3][2]= {{1,2},{3,4},{5,6}};                     /* float */

	/* create 3D attributes with dimension [4][3][2], 24 elements */
 hsize_t    dims3[3]={4,3,2};
	char       buf13[24][2]= {"ab","cd","ef","gh","ij","kl","mn","pq",
	"rs","tu","vw","xz","AB","CD","EF","GH",
	"IJ","KL","MN","PQ","RS","TU","VW","XZ"};  /* string */
 char       buf23[4][3][2];    /* bitfield, opaque */
 s_t        buf33[4][3][2];    /* compound */
 hobj_ref_t buf43[4][3][2];    /* reference */
 hvl_t      buf53[4][3][2];    /* vlen */
 int        buf63[24][3];      /* array */
	int        buf73[4][3][2];    /* integer */
	float      buf83[4][3][2];    /* float */


/*-------------------------------------------------------------------------
 * 1D attributes
 *-------------------------------------------------------------------------
 */
	
/*-------------------------------------------------------------------------
 * H5T_STRING
 *-------------------------------------------------------------------------
 */
	type_id = H5Tcopy(H5T_C_S1);
 status  = H5Tset_size(type_id, 2);
 write_attr(loc_id,1,dims,"string",type_id,buf1);
 status = H5Tclose(type_id);

/*-------------------------------------------------------------------------
 * H5T_BITFIELD
 *-------------------------------------------------------------------------
 */
 type_id = H5Tcopy(H5T_STD_B8LE);
 write_attr(loc_id,1,dims,"bitfield",type_id,buf2);
 status = H5Tclose(type_id);

/*-------------------------------------------------------------------------
 * H5T_OPAQUE
 *-------------------------------------------------------------------------
 */
 type_id = H5Tcreate(H5T_OPAQUE, 1);
 status = H5Tset_tag(type_id, "1-byte opaque type"); /* must set this */
 write_attr(loc_id,1,dims,"opaque",type_id,buf2);
 status = H5Tclose(type_id);

/*-------------------------------------------------------------------------
 * H5T_COMPOUND
 *-------------------------------------------------------------------------
 */

 type_str_id = H5Tcopy( H5T_C_S1 );
 H5Tset_size( type_str_id, 16 );
 type_id = H5Tcreate (H5T_COMPOUND, sizeof(s_t));
 H5Tinsert(type_id, "Name", HOFFSET(s_t, name), type_str_id);
	H5Tinsert(type_id, "Latitude", HOFFSET(s_t, lati), H5T_NATIVE_INT);
	H5Tinsert(type_id, "Longitude", HOFFSET(s_t, longi), H5T_NATIVE_INT);
	H5Tinsert(type_id, "Pressure", HOFFSET(s_t, pressure), H5T_NATIVE_FLOAT);
	H5Tinsert(type_id, "Temperature", HOFFSET(s_t, temperature), H5T_NATIVE_DOUBLE);
 write_attr(loc_id,1,dims,"compound",type_id,buf3);
 status = H5Tclose(type_id);
 
/*-------------------------------------------------------------------------
 * H5T_REFERENCE
 *-------------------------------------------------------------------------
 */
 /* Create references to dataset */
	if (dset_name)
	{
		status=H5Rcreate(&buf4[0],file_id,dset_name,H5R_OBJECT,-1);
		status=H5Rcreate(&buf4[1],file_id,dset_name,H5R_OBJECT,-1);
		write_attr(loc_id,1,dims,"reference",H5T_STD_REF_OBJ,buf4);
	}

/*-------------------------------------------------------------------------
 * H5T_ENUM
 *-------------------------------------------------------------------------
 */
 type_id = H5Tcreate(H5T_ENUM, sizeof(e_t));
 H5Tenum_insert(type_id, "RED",   (val = 0, &val));
 H5Tenum_insert(type_id, "GREEN", (val = 1, &val));
 write_attr(loc_id,1,dims,"enum",type_id,0);
 status = H5Tclose(type_id);

/*-------------------------------------------------------------------------
 * H5T_VLEN
 *-------------------------------------------------------------------------
 */
 
 /* Allocate and initialize VL dataset to write */

	buf5[0].len = 1;
	buf5[0].p = malloc( 1 * sizeof(int));
	((int *)buf5[0].p)[0]=1;
	buf5[1].len = 2;
	buf5[1].p = malloc( 2 * sizeof(int));
	((int *)buf5[1].p)[0]=2;
	((int *)buf5[1].p)[1]=3;

 space_id = H5Screate_simple(1,dims,NULL);
 type_id = H5Tvlen_create(H5T_NATIVE_INT);
 attr_id = H5Acreate(loc_id,"vlen",type_id,space_id,H5P_DEFAULT);
 status = H5Awrite(attr_id,type_id,buf5);
 assert(status>=0);
 status = H5Dvlen_reclaim(type_id,space_id,H5P_DEFAULT,buf5);
 assert(status>=0);
 status = H5Aclose(attr_id);
 status = H5Tclose(type_id);
 status = H5Sclose(space_id);

/*-------------------------------------------------------------------------
 * H5T_ARRAY
 *-------------------------------------------------------------------------
 */
 type_id = H5Tarray_create(H5T_NATIVE_INT,1,dimarray,NULL);
 write_attr(loc_id,1,dims,"array",type_id,buf6);
 status = H5Tclose(type_id);

/*-------------------------------------------------------------------------
 * H5T_INTEGER and H5T_FLOAT
 *-------------------------------------------------------------------------
 */
 write_attr(loc_id,1,dims,"integer",H5T_NATIVE_INT,buf7);
 write_attr(loc_id,1,dims,"float",H5T_NATIVE_FLOAT,buf8);


/*-------------------------------------------------------------------------
 * 2D attributes
 *-------------------------------------------------------------------------
 */

/*-------------------------------------------------------------------------
 * H5T_STRING
 *-------------------------------------------------------------------------
 */
	type_id = H5Tcopy(H5T_C_S1);
 status  = H5Tset_size(type_id, 2);
 write_attr(loc_id,2,dims2,"string2D",type_id,buf12);
 status = H5Tclose(type_id);

/*-------------------------------------------------------------------------
 * H5T_BITFIELD
 *-------------------------------------------------------------------------
 */
 type_id = H5Tcopy(H5T_STD_B8LE);
 write_attr(loc_id,2,dims2,"bitfield2D",type_id,buf22);
 status = H5Tclose(type_id);

/*-------------------------------------------------------------------------
 * H5T_OPAQUE
 *-------------------------------------------------------------------------
 */
 type_id = H5Tcreate(H5T_OPAQUE, 1);
 status = H5Tset_tag(type_id, "1-byte opaque type"); /* must set this */
 write_attr(loc_id,2,dims2,"opaque2D",type_id,buf22);
 status = H5Tclose(type_id);

/*-------------------------------------------------------------------------
 * H5T_COMPOUND
 *-------------------------------------------------------------------------
 */
 type_str_id = H5Tcopy( H5T_C_S1 );
 H5Tset_size( type_str_id, 16 );
 type_id = H5Tcreate (H5T_COMPOUND, sizeof(s_t));
 H5Tinsert(type_id, "Name", HOFFSET(s_t, name), type_str_id);
	H5Tinsert(type_id, "Latitude", HOFFSET(s_t, lati), H5T_NATIVE_INT);
	H5Tinsert(type_id, "Longitude", HOFFSET(s_t, longi), H5T_NATIVE_INT);
	H5Tinsert(type_id, "Pressure", HOFFSET(s_t, pressure), H5T_NATIVE_FLOAT);
	H5Tinsert(type_id, "Temperature", HOFFSET(s_t, temperature), H5T_NATIVE_DOUBLE);
 write_attr(loc_id,2,dims2,"compound2D",type_id,buf32);
 status = H5Tclose(type_id);
 
/*-------------------------------------------------------------------------
 * H5T_REFERENCE
 *-------------------------------------------------------------------------
 */
 /* Create references to dataset */
	if (dset_name)
	{
		for (i = 0; i < 3; i++) {
   for (j = 0; j < 2; j++) {
    status=H5Rcreate(&buf42[i][j],file_id,dset_name,H5R_OBJECT,-1);
			}
		}
		write_attr(loc_id,2,dims2,"reference2D",H5T_STD_REF_OBJ,buf42);
	}

/*-------------------------------------------------------------------------
 * H5T_ENUM
 *-------------------------------------------------------------------------
 */
 type_id = H5Tcreate(H5T_ENUM, sizeof(e_t));
 H5Tenum_insert(type_id, "RED",   (val = 0, &val));
 H5Tenum_insert(type_id, "GREEN", (val = 1, &val));
 write_attr(loc_id,2,dims2,"enum2D",type_id,0);
 status = H5Tclose(type_id);

/*-------------------------------------------------------------------------
 * H5T_VLEN
 *-------------------------------------------------------------------------
 */

	/* Allocate and initialize VL dataset to write */
	n=0;
	for (i = 0; i < 3; i++) {
		for (j = 0; j < 2; j++) {
		  int l;
		  buf52[i][j].p = malloc((i + 1) * sizeof(int));
		  buf52[i][j].len = i + 1;
		  for (l = 0; l < i + 1; l++)
			 ((int *)buf52[i][j].p)[l] = n++;
		}
	}
 
 space_id = H5Screate_simple(2,dims2,NULL);
 type_id = H5Tvlen_create(H5T_NATIVE_INT);
 attr_id = H5Acreate(loc_id,"vlen2D",type_id,space_id,H5P_DEFAULT);
 status = H5Awrite(attr_id,type_id,buf52);
 assert(status>=0);
 status = H5Dvlen_reclaim(type_id,space_id,H5P_DEFAULT,buf52);
 assert(status>=0);
 status = H5Aclose(attr_id);
 status = H5Tclose(type_id);
 status = H5Sclose(space_id);

/*-------------------------------------------------------------------------
 * H5T_ARRAY
 *-------------------------------------------------------------------------
 */
 type_id = H5Tarray_create(H5T_NATIVE_INT,1,dimarray,NULL);
 write_attr(loc_id,2,dims2,"array2D",type_id,buf62);
 status = H5Tclose(type_id);

/*-------------------------------------------------------------------------
 * H5T_INTEGER and H5T_FLOAT
 *-------------------------------------------------------------------------
 */
 write_attr(loc_id,2,dims2,"integer2D",H5T_NATIVE_INT,buf72);
 write_attr(loc_id,2,dims2,"float2D",H5T_NATIVE_FLOAT,buf82);

	
/*-------------------------------------------------------------------------
 * 3D attributes
 *-------------------------------------------------------------------------
 */

/*-------------------------------------------------------------------------
 * H5T_STRING
 *-------------------------------------------------------------------------
 */
	type_id = H5Tcopy(H5T_C_S1);
 status  = H5Tset_size(type_id, 2);
 write_attr(loc_id,3,dims3,"string3D",type_id,buf13);
 status = H5Tclose(type_id);

/*-------------------------------------------------------------------------
 * H5T_BITFIELD
 *-------------------------------------------------------------------------
 */

	n=1;
	for (i = 0; i < 4; i++) {
		for (j = 0; j < 3; j++) {
			for (k = 0; k < 2; k++) {
				buf23[i][j][k]=n++;
			}
		}
	}
 type_id = H5Tcopy(H5T_STD_B8LE);
 write_attr(loc_id,3,dims3,"bitfield3D",type_id,buf23);
 status = H5Tclose(type_id);

/*-------------------------------------------------------------------------
 * H5T_OPAQUE
 *-------------------------------------------------------------------------
 */
 type_id = H5Tcreate(H5T_OPAQUE, 1);
 status = H5Tset_tag(type_id, "1-byte opaque type"); /* must set this */
 write_attr(loc_id,3,dims3,"opaque3D",type_id,buf23);
 status = H5Tclose(type_id);

/*-------------------------------------------------------------------------
 * H5T_COMPOUND
 *-------------------------------------------------------------------------
 */

	n=1;
	for (i = 0; i < 4; i++) {
		for (j = 0; j < 3; j++) {
			for (k = 0; k < 2; k++) {
				sprintf(str,"name %d",n);
				strcpy(buf33[i][j][k].name,str);
				buf33[i][j][k].lati=n++;
				buf33[i][j][k].longi=n;
				buf33[i][j][k].pressure=10;
				buf33[i][j][k].temperature=60;
			}
		}
	}
 type_str_id = H5Tcopy( H5T_C_S1 );
 H5Tset_size( type_str_id, 16 );
 type_id = H5Tcreate (H5T_COMPOUND, sizeof(s_t));
 H5Tinsert(type_id, "Name", HOFFSET(s_t, name), type_str_id);
	H5Tinsert(type_id, "Latitude", HOFFSET(s_t, lati), H5T_NATIVE_INT);
	H5Tinsert(type_id, "Longitude", HOFFSET(s_t, longi), H5T_NATIVE_INT);
	H5Tinsert(type_id, "Pressure", HOFFSET(s_t, pressure), H5T_NATIVE_FLOAT);
	H5Tinsert(type_id, "Temperature", HOFFSET(s_t, temperature), H5T_NATIVE_DOUBLE);
 write_attr(loc_id,3,dims3,"compound3D",type_id,buf33);
 status = H5Tclose(type_id);
 
/*-------------------------------------------------------------------------
 * H5T_REFERENCE
 *-------------------------------------------------------------------------
 */
 /* Create references to dataset */
	if (dset_name)
	{
		for (i = 0; i < 4; i++) {
   for (j = 0; j < 3; j++) {
    for (k = 0; k < 2; k++)
     status=H5Rcreate(&buf43[i][j][k],file_id,dset_name,H5R_OBJECT,-1);
			}
		}
	write_attr(loc_id,3,dims3,"reference3D",H5T_STD_REF_OBJ,buf43);
	}

/*-------------------------------------------------------------------------
 * H5T_ENUM
 *-------------------------------------------------------------------------
 */
 type_id = H5Tcreate(H5T_ENUM, sizeof(e_t));
 H5Tenum_insert(type_id, "RED",   (val = 0, &val));
 H5Tenum_insert(type_id, "GREEN", (val = 1, &val));
 write_attr(loc_id,3,dims3,"enum3D",type_id,0);
 status = H5Tclose(type_id);

/*-------------------------------------------------------------------------
 * H5T_VLEN
 *-------------------------------------------------------------------------
 */
 
	/* Allocate and initialize VL dataset to write */
	n=0;
	for (i = 0; i < 4; i++) {
		for (j = 0; j < 3; j++) {
			for (k = 0; k < 2; k++) {
		  int l;
		  buf53[i][j][k].p = malloc((i + 1) * sizeof(int));
		  buf53[i][j][k].len = i + 1;
		  for (l = 0; l < i + 1; l++)
			 ((int *)buf53[i][j][k].p)[l] = n++;
			}
		}
	}
 
 space_id = H5Screate_simple(3,dims3,NULL);
 type_id = H5Tvlen_create(H5T_NATIVE_INT);
 attr_id = H5Acreate(loc_id,"vlen3D",type_id,space_id,H5P_DEFAULT);
 status = H5Awrite(attr_id,type_id,buf53);
 assert(status>=0);
 status = H5Dvlen_reclaim(type_id,space_id,H5P_DEFAULT,buf53);
 assert(status>=0);
 status = H5Aclose(attr_id);
 status = H5Tclose(type_id);
 status = H5Sclose(space_id);

/*-------------------------------------------------------------------------
 * H5T_ARRAY
 *-------------------------------------------------------------------------
 */
 n=1;
	for (i = 0; i < 24; i++) {
		for (j = 0; j < (int)dimarray[0]; j++) {
				buf63[i][j]=n++;
		}
	}

 type_id = H5Tarray_create(H5T_NATIVE_INT,1,dimarray,NULL);
 write_attr(loc_id,3,dims3,"array3D",type_id,buf63);
 status = H5Tclose(type_id);

/*-------------------------------------------------------------------------
 * H5T_INTEGER and H5T_FLOAT
 *-------------------------------------------------------------------------
 */
	n=1; f=1;
	for (i = 0; i < 4; i++) {
		for (j = 0; j < 3; j++) {
			for (k = 0; k < 2; k++) {
				buf73[i][j][k]=n++;
				buf83[i][j][k]=f++;
			}
		}
	}
 write_attr(loc_id,3,dims3,"integer3D",H5T_NATIVE_INT,buf73);
 write_attr(loc_id,3,dims3,"float3D",H5T_NATIVE_FLOAT,buf83);
}



/*-------------------------------------------------------------------------
 * Function: write_dset_in
 *
 * Purpose: write datasets in LOC_ID 
 *
 *-------------------------------------------------------------------------
 */

static void write_dset_in(hid_t loc_id, 
																										const char* dset_name, /* for saving reference to dataset*/
																										hid_t file_id)
{
  /* Compound datatype */
	typedef struct s_t 
 {
  char   name[16];
  int    lati;
  int    longi;
  float  pressure;
  double temperature; 
 } s_t;

 typedef enum 
 {
  E_RED,
  E_GREEN
 } e_t;

 hid_t   dset_id;
 hid_t   space_id;  
 hid_t   type_id, type_str_id;  
	hid_t   plist_id;
 herr_t  status;
 int     val, i, j, k, n;
	float   f;
	int     fillvalue=2;
	char    str[20];

	/* create 1D attributes with dimension [2], 2 elements */
 hsize_t    dims[1]={2};
	char       buf1[2][2]= {"ab","de"};        /* string */
 char       buf2[2]= {1,2};                 /* bitfield, opaque */
 s_t        buf3[2]= {{1,2},{3,4}};         /* compound */
 hobj_ref_t buf4[2];                        /* reference */
 hvl_t      buf5[2];                        /* vlen */
 hsize_t    dimarray[1]={3};                /* array dimension */
 int        buf6[2][3]= {{1,2,3},{4,5,6}};  /* array */
	int        buf7[2]= {1,2};                 /* integer */
	float      buf8[2]= {1,2};                 /* float */

	/* create 2D attributes with dimension [3][2], 6 elements */
 hsize_t    dims2[2]={3,2};
	char       buf12[6][2]= {"ab","cd","ef","gh","ij","kl"};         /* string */
 char       buf22[3][2]= {{1,2},{3,4},{5,6}};                     /* bitfield, opaque */
 s_t        buf32[6]= {{1,2},{3,4},{5,6},{7,8},{9,10},{11,12}};   /* compound */
 hobj_ref_t buf42[3][2];                                          /* reference */
 hvl_t      buf52[3][2];                                          /* vlen */
 int        buf62[6][3]= {{1,2,3},{4,5,6},{7,8,9},{10,11,12},{13,14,15},{16,17,18}};  /* array */
	int        buf72[3][2]= {{1,2},{3,4},{5,6}};                     /* integer */
	float      buf82[3][2]= {{1,2},{3,4},{5,6}};                     /* float */

	/* create 3D attributes with dimension [4][3][2], 24 elements */
 hsize_t    dims3[3]={4,3,2};
	char       buf13[24][2]= {"ab","cd","ef","gh","ij","kl","mn","pq",
	"rs","tu","vw","xz","AB","CD","EF","GH",
	"IJ","KL","MN","PQ","RS","TU","VW","XZ"};  /* string */
 char       buf23[4][3][2];    /* bitfield, opaque */
 s_t        buf33[4][3][2];    /* compound */
 hobj_ref_t buf43[4][3][2];    /* reference */
 hvl_t      buf53[4][3][2];    /* vlen */
 int        buf63[24][3];      /* array */
	int        buf73[4][3][2];    /* integer */
	float      buf83[4][3][2];    /* float */


/*-------------------------------------------------------------------------
 * 1D 
 *-------------------------------------------------------------------------
 */
	
/*-------------------------------------------------------------------------
 * H5T_STRING
 *-------------------------------------------------------------------------
 */
	type_id = H5Tcopy(H5T_C_S1);
 status  = H5Tset_size(type_id, 2);
 write_dset(loc_id,1,dims,"string",type_id,buf1);
 status = H5Tclose(type_id);

/*-------------------------------------------------------------------------
 * H5T_BITFIELD
 *-------------------------------------------------------------------------
 */
 type_id = H5Tcopy(H5T_STD_B8LE);
 write_dset(loc_id,1,dims,"bitfield",type_id,buf2);
 status = H5Tclose(type_id);

/*-------------------------------------------------------------------------
 * H5T_OPAQUE
 *-------------------------------------------------------------------------
 */
 type_id = H5Tcreate(H5T_OPAQUE, 1);
 status = H5Tset_tag(type_id, "1-byte opaque type"); /* must set this */
 write_dset(loc_id,1,dims,"opaque",type_id,buf2);
 status = H5Tclose(type_id);

/*-------------------------------------------------------------------------
 * H5T_COMPOUND
 *-------------------------------------------------------------------------
 */
 type_str_id = H5Tcopy( H5T_C_S1 );
 H5Tset_size( type_str_id, 16 );
 type_id = H5Tcreate (H5T_COMPOUND, sizeof(s_t));
 H5Tinsert(type_id, "Name", HOFFSET(s_t, name), type_str_id);
	H5Tinsert(type_id, "Latitude", HOFFSET(s_t, lati), H5T_NATIVE_INT);
	H5Tinsert(type_id, "Longitude", HOFFSET(s_t, longi), H5T_NATIVE_INT);
	H5Tinsert(type_id, "Pressure", HOFFSET(s_t, pressure), H5T_NATIVE_FLOAT);
	H5Tinsert(type_id, "Temperature", HOFFSET(s_t, temperature), H5T_NATIVE_DOUBLE);
 write_dset(loc_id,1,dims,"compound",type_id,buf3);
 status = H5Tclose(type_id);
 
/*-------------------------------------------------------------------------
 * H5T_REFERENCE
 *-------------------------------------------------------------------------
 */
 /* Create references to dataset */
	if (dset_name)
	{
		status=H5Rcreate(&buf4[0],file_id,dset_name,H5R_OBJECT,-1);
		status=H5Rcreate(&buf4[1],file_id,dset_name,H5R_OBJECT,-1);
		write_dset(loc_id,1,dims,"reference",H5T_STD_REF_OBJ,buf4);
	}

/*-------------------------------------------------------------------------
 * H5T_ENUM
 *-------------------------------------------------------------------------
 */
 type_id = H5Tcreate(H5T_ENUM, sizeof(e_t));
 H5Tenum_insert(type_id, "RED",   (val = 0, &val));
 H5Tenum_insert(type_id, "GREEN", (val = 1, &val));
 write_dset(loc_id,1,dims,"enum",type_id,0);
 status = H5Tclose(type_id);

/*-------------------------------------------------------------------------
 * H5T_VLEN
 *-------------------------------------------------------------------------
 */
 
 /* Allocate and initialize VL dataset to write */

	buf5[0].len = 1;
	buf5[0].p = malloc( 1 * sizeof(int));
	((int *)buf5[0].p)[0]=1;
	buf5[1].len = 2;
	buf5[1].p = malloc( 2 * sizeof(int));
	((int *)buf5[1].p)[0]=2;
	((int *)buf5[1].p)[1]=3;

 space_id = H5Screate_simple(1,dims,NULL);
 type_id = H5Tvlen_create(H5T_NATIVE_INT);
 dset_id = H5Dcreate(loc_id,"vlen",type_id,space_id,H5P_DEFAULT);
 status = H5Dwrite(dset_id,type_id,H5S_ALL,H5S_ALL,H5P_DEFAULT,buf5);
 assert(status>=0);
 status = H5Dvlen_reclaim(type_id,space_id,H5P_DEFAULT,buf5);
 assert(status>=0);
 status = H5Dclose(dset_id);
 status = H5Tclose(type_id);
 status = H5Sclose(space_id);

/*-------------------------------------------------------------------------
 * H5T_ARRAY
 *-------------------------------------------------------------------------
 */
 type_id = H5Tarray_create(H5T_NATIVE_INT,1,dimarray,NULL);
 write_dset(loc_id,1,dims,"array",type_id,buf6);
 status = H5Tclose(type_id);

/*-------------------------------------------------------------------------
 * H5T_INTEGER and H5T_FLOAT
 *-------------------------------------------------------------------------
 */
 write_dset(loc_id,1,dims,"integer",H5T_NATIVE_INT,buf7);
 write_dset(loc_id,1,dims,"float",H5T_NATIVE_FLOAT,buf8);


/*-------------------------------------------------------------------------
 * 2D 
 *-------------------------------------------------------------------------
 */

/*-------------------------------------------------------------------------
 * H5T_STRING
 *-------------------------------------------------------------------------
 */
	type_id = H5Tcopy(H5T_C_S1);
 status  = H5Tset_size(type_id, 2);
 write_dset(loc_id,2,dims2,"string2D",type_id,buf12);
 status = H5Tclose(type_id);

/*-------------------------------------------------------------------------
 * H5T_BITFIELD
 *-------------------------------------------------------------------------
 */
 type_id = H5Tcopy(H5T_STD_B8LE);
 write_dset(loc_id,2,dims2,"bitfield2D",type_id,buf22);
 status = H5Tclose(type_id);

/*-------------------------------------------------------------------------
 * H5T_OPAQUE
 *-------------------------------------------------------------------------
 */
 type_id = H5Tcreate(H5T_OPAQUE, 1);
 status = H5Tset_tag(type_id, "1-byte opaque type"); /* must set this */
 write_dset(loc_id,2,dims2,"opaque2D",type_id,buf22);
 status = H5Tclose(type_id);

/*-------------------------------------------------------------------------
 * H5T_COMPOUND
 *-------------------------------------------------------------------------
 */
 type_str_id = H5Tcopy( H5T_C_S1 );
 H5Tset_size( type_str_id, 16 );
 type_id = H5Tcreate (H5T_COMPOUND, sizeof(s_t));
 H5Tinsert(type_id, "Name", HOFFSET(s_t, name), type_str_id);
	H5Tinsert(type_id, "Latitude", HOFFSET(s_t, lati), H5T_NATIVE_INT);
	H5Tinsert(type_id, "Longitude", HOFFSET(s_t, longi), H5T_NATIVE_INT);
	H5Tinsert(type_id, "Pressure", HOFFSET(s_t, pressure), H5T_NATIVE_FLOAT);
	H5Tinsert(type_id, "Temperature", HOFFSET(s_t, temperature), H5T_NATIVE_DOUBLE);
 write_dset(loc_id,2,dims2,"compound2D",type_id,buf32);
 status = H5Tclose(type_id);
 
/*-------------------------------------------------------------------------
 * H5T_REFERENCE
 *-------------------------------------------------------------------------
 */
 /* Create references to dataset */
	if (dset_name)
	{
		for (i = 0; i < 3; i++) {
   for (j = 0; j < 2; j++) {
    status=H5Rcreate(&buf42[i][j],file_id,dset_name,H5R_OBJECT,-1);
			}
		}
		write_dset(loc_id,2,dims2,"reference2D",H5T_STD_REF_OBJ,buf42);
	}

/*-------------------------------------------------------------------------
 * H5T_ENUM
 *-------------------------------------------------------------------------
 */
 type_id = H5Tcreate(H5T_ENUM, sizeof(e_t));
 H5Tenum_insert(type_id, "RED",   (val = 0, &val));
 H5Tenum_insert(type_id, "GREEN", (val = 1, &val));
 write_dset(loc_id,2,dims2,"enum2D",type_id,0);
 status = H5Tclose(type_id);

/*-------------------------------------------------------------------------
 * H5T_VLEN
 *-------------------------------------------------------------------------
 */

	/* Allocate and initialize VL dataset to write */
	n=0;
	for (i = 0; i < 3; i++) {
		for (j = 0; j < 2; j++) {
		  int l;
		  buf52[i][j].p = malloc((i + 1) * sizeof(int));
		  buf52[i][j].len = i + 1;
		  for (l = 0; l < i + 1; l++)
			 ((int *)buf52[i][j].p)[l] = n++;
		}
	}
 
 space_id = H5Screate_simple(2,dims2,NULL);
 type_id = H5Tvlen_create(H5T_NATIVE_INT);
 dset_id = H5Dcreate(loc_id,"vlen2D",type_id,space_id,H5P_DEFAULT);
 status = H5Dwrite(dset_id,type_id,H5S_ALL,H5S_ALL,H5P_DEFAULT,buf52);
 assert(status>=0);
 status = H5Dvlen_reclaim(type_id,space_id,H5P_DEFAULT,buf52);
 assert(status>=0);
 status = H5Dclose(dset_id);
 status = H5Tclose(type_id);
 status = H5Sclose(space_id);

/*-------------------------------------------------------------------------
 * H5T_ARRAY
 *-------------------------------------------------------------------------
 */
 type_id = H5Tarray_create(H5T_NATIVE_INT,1,dimarray,NULL);
 write_dset(loc_id,2,dims2,"array2D",type_id,buf62);
 status = H5Tclose(type_id);

/*-------------------------------------------------------------------------
 * H5T_INTEGER, write a fill value
 *-------------------------------------------------------------------------
 */
	plist_id = H5Pcreate(H5P_DATASET_CREATE);
	status = H5Pset_fill_value(plist_id, H5T_NATIVE_INT, &fillvalue);
	space_id = H5Screate_simple(2,dims2,NULL);
	dset_id = H5Dcreate(loc_id,"integer2D",H5T_NATIVE_INT,space_id,plist_id);
	status = H5Dwrite(dset_id,H5T_NATIVE_INT,H5S_ALL,H5S_ALL,H5P_DEFAULT,buf72);
	status = H5Pclose(plist_id);
	status = H5Dclose(dset_id);
 status = H5Sclose(space_id);

/*-------------------------------------------------------------------------
 * H5T_FLOAT
 *-------------------------------------------------------------------------
 */

 write_dset(loc_id,2,dims2,"float2D",H5T_NATIVE_FLOAT,buf82);

	
/*-------------------------------------------------------------------------
 * 3D 
 *-------------------------------------------------------------------------
 */

/*-------------------------------------------------------------------------
 * H5T_STRING
 *-------------------------------------------------------------------------
 */
	type_id = H5Tcopy(H5T_C_S1);
 status  = H5Tset_size(type_id, 2);
 write_dset(loc_id,3,dims3,"string3D",type_id,buf13);
 status = H5Tclose(type_id);

/*-------------------------------------------------------------------------
 * H5T_BITFIELD
 *-------------------------------------------------------------------------
 */

	n=1;
	for (i = 0; i < 4; i++) {
		for (j = 0; j < 3; j++) {
			for (k = 0; k < 2; k++) {
				buf23[i][j][k]=n++;
			}
		}
	}
 type_id = H5Tcopy(H5T_STD_B8LE);
 write_dset(loc_id,3,dims3,"bitfield3D",type_id,buf23);
 status = H5Tclose(type_id);

/*-------------------------------------------------------------------------
 * H5T_OPAQUE
 *-------------------------------------------------------------------------
 */
 type_id = H5Tcreate(H5T_OPAQUE, 1);
 status = H5Tset_tag(type_id, "1-byte opaque type"); /* must set this */
 write_dset(loc_id,3,dims3,"opaque3D",type_id,buf23);
 status = H5Tclose(type_id);

/*-------------------------------------------------------------------------
 * H5T_COMPOUND
 *-------------------------------------------------------------------------
 */

	n=1;
	for (i = 0; i < 4; i++) {
		for (j = 0; j < 3; j++) {
			for (k = 0; k < 2; k++) {
				sprintf(str,"name %d",n);
				strcpy(buf33[i][j][k].name,str);
				buf33[i][j][k].lati=n++;
				buf33[i][j][k].longi=n;
				buf33[i][j][k].pressure=10;
				buf33[i][j][k].temperature=60;
			}
		}
	}
 type_str_id = H5Tcopy( H5T_C_S1 );
 H5Tset_size( type_str_id, 16 );
 type_id = H5Tcreate (H5T_COMPOUND, sizeof(s_t));
 H5Tinsert(type_id, "Name", HOFFSET(s_t, name), type_str_id);
	H5Tinsert(type_id, "Latitude", HOFFSET(s_t, lati), H5T_NATIVE_INT);
	H5Tinsert(type_id, "Longitude", HOFFSET(s_t, longi), H5T_NATIVE_INT);
	H5Tinsert(type_id, "Pressure", HOFFSET(s_t, pressure), H5T_NATIVE_FLOAT);
	H5Tinsert(type_id, "Temperature", HOFFSET(s_t, temperature), H5T_NATIVE_DOUBLE);
 write_dset(loc_id,3,dims3,"compound3D",type_id,buf33);
 status = H5Tclose(type_id);
 
/*-------------------------------------------------------------------------
 * H5T_REFERENCE
 *-------------------------------------------------------------------------
 */
 /* Create references to dataset */
	if (dset_name)
	{
		for (i = 0; i < 4; i++) {
   for (j = 0; j < 3; j++) {
    for (k = 0; k < 2; k++)
     status=H5Rcreate(&buf43[i][j][k],file_id,dset_name,H5R_OBJECT,-1);
			}
		}
	write_dset(loc_id,3,dims3,"reference3D",H5T_STD_REF_OBJ,buf43);
	}

/*-------------------------------------------------------------------------
 * H5T_ENUM
 *-------------------------------------------------------------------------
 */
 type_id = H5Tcreate(H5T_ENUM, sizeof(e_t));
 H5Tenum_insert(type_id, "RED",   (val = 0, &val));
 H5Tenum_insert(type_id, "GREEN", (val = 1, &val));
 write_dset(loc_id,3,dims3,"enum3D",type_id,0);
 status = H5Tclose(type_id);

/*-------------------------------------------------------------------------
 * H5T_VLEN
 *-------------------------------------------------------------------------
 */
 
	/* Allocate and initialize VL dataset to write */
	n=0;
	for (i = 0; i < 4; i++) {
		for (j = 0; j < 3; j++) {
			for (k = 0; k < 2; k++) {
		  int l;
		  buf53[i][j][k].p = malloc((i + 1) * sizeof(int));
		  buf53[i][j][k].len = i + 1;
		  for (l = 0; l < i + 1; l++)
			 ((int *)buf53[i][j][k].p)[l] = n++;
			}
		}
	}
 
 space_id = H5Screate_simple(3,dims3,NULL);
 type_id = H5Tvlen_create(H5T_NATIVE_INT);
 dset_id = H5Dcreate(loc_id,"vlen3D",type_id,space_id,H5P_DEFAULT);
 status = H5Dwrite(dset_id,type_id,H5S_ALL,H5S_ALL,H5P_DEFAULT,buf53);
 assert(status>=0);
 status = H5Dvlen_reclaim(type_id,space_id,H5P_DEFAULT,buf53);
 assert(status>=0);
 status = H5Dclose(dset_id);
 status = H5Tclose(type_id);
 status = H5Sclose(space_id);

/*-------------------------------------------------------------------------
 * H5T_ARRAY
 *-------------------------------------------------------------------------
 */
 n=1;
	for (i = 0; i < 24; i++) {
		for (j = 0; j < (int)dimarray[0]; j++) {
				buf63[i][j]=n++;
		}
	}

 type_id = H5Tarray_create(H5T_NATIVE_INT,1,dimarray,NULL);
 write_dset(loc_id,3,dims3,"array3D",type_id,buf63);
 status = H5Tclose(type_id);

/*-------------------------------------------------------------------------
 * H5T_INTEGER and H5T_FLOAT
 *-------------------------------------------------------------------------
 */
	n=1; f=1;
	for (i = 0; i < 4; i++) {
		for (j = 0; j < 3; j++) {
			for (k = 0; k < 2; k++) {
				buf73[i][j][k]=n++;
				buf83[i][j][k]=f++;
			}
		}
	}
 write_dset(loc_id,3,dims3,"integer3D",H5T_NATIVE_INT,buf73);
 write_dset(loc_id,3,dims3,"float3D",H5T_NATIVE_FLOAT,buf83);
}




/*-------------------------------------------------------------------------
 * Function: make_data
 *
 * Purpose: generate all datatype attributes  
 *
 *-------------------------------------------------------------------------
 */

static void make_data(void)
{
 hid_t   file_id; 
 hid_t   dset_id;
	hid_t   group_id;
	hid_t   group2_id;
	hid_t   root_id;
	hid_t   space_id;
	hsize_t dims[1]={2};
 herr_t  status;

 /* Create a file and a dataset */
 file_id  = H5Fcreate(FILE_NAME, H5F_ACC_TRUNC, H5P_DEFAULT, H5P_DEFAULT); 

	/* Create a 1D dataset */
 space_id = H5Screate_simple(1,dims,NULL);
 dset_id  = H5Dcreate(file_id,"dset",H5T_NATIVE_INT,space_id,H5P_DEFAULT);
 status   = H5Sclose(space_id);

	/* Create groups */
 group_id  = H5Gcreate(file_id,"g1",0);
	group2_id = H5Gcreate(file_id,"g2",0);
 root_id   = H5Gopen(file_id, "/");

/*-------------------------------------------------------------------------
 * write a series of attributes on the dataset, group
 *-------------------------------------------------------------------------
 */

	write_attr_in(dset_id,"dset",file_id);
	write_attr_in(group_id,NULL,0);
	write_attr_in(root_id,NULL,0);

/*-------------------------------------------------------------------------
 * write a series of datasets on group 2
 *-------------------------------------------------------------------------
 */

	write_dset_in(group2_id,"/dset",file_id);

 /* Close */
 status = H5Dclose(dset_id);
	status = H5Gclose(group_id);
	status = H5Gclose(group2_id);
	status = H5Gclose(root_id);

	/* Close file */
 status = H5Fclose(file_id);
}


/*-------------------------------------------------------------------------
 * Function: write_attr
 *
 * Purpose: utility function to write an attribute
 *
 *-------------------------------------------------------------------------
 */

static 
int write_attr(hid_t loc_id, int rank, hsize_t *dims, const char *attr_name,
               hid_t type_id, void *buf)
{
 hid_t   attr_id;
 hid_t   space_id;  
 herr_t  status;

 /* Create a buf space  */
 space_id = H5Screate_simple(rank,dims,NULL);

 /* Create the attribute */
 attr_id = H5Acreate(loc_id,attr_name,type_id,space_id,H5P_DEFAULT);
  
 /* Write the buf */
 if ( buf )
  status = H5Awrite(attr_id,type_id,buf);

 /* Close */
 status = H5Aclose(attr_id);
 status = H5Sclose(space_id);
 return status;
}

/*-------------------------------------------------------------------------
 * Function: write_dset
 *
 * Purpose: utility function to create and write a dataset in LOC_ID
 *
 *-------------------------------------------------------------------------
 */

static
int write_dset( hid_t loc_id, int rank, hsize_t *dims, const char *dset_name,
                hid_t type_id, void *buf )
{
 hid_t   dset_id;
 hid_t   space_id;  
 herr_t  status;

 /* Create a buf space  */
 space_id = H5Screate_simple(rank,dims,NULL);

 /* Create a dataset */
 dset_id = H5Dcreate(loc_id,dset_name,type_id,space_id,H5P_DEFAULT);
  
 /* Write the buf */
 if ( buf )
  status = H5Dwrite(dset_id,type_id,H5S_ALL,H5S_ALL,H5P_DEFAULT,buf);

 /* Close */
 status = H5Dclose(dset_id);
 status = H5Sclose(space_id);

 return status;

}



/*-------------------------------------------------------------------------
 * Function: main
 *
 *-------------------------------------------------------------------------
 */


int main(void)
{
 make_data();
 return 0;
}
