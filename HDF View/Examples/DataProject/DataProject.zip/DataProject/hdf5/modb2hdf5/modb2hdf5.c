

#include "hdf5.h"

#define COLS    167 //cols   i  IMAX
#define ROWS    63  //rows   j  JMAX              
#define LAYERS  34  //layers k  KMAX
#define RANK    3

float data[LAYERS][ROWS][COLS];

#define THREED

int main (void)
{
    
	hid_t     file_id;     /* HDF5 file handle */
	hid_t     dset_id;     /* HDF5 dataset handle */
	hid_t     plist;       /* dataset property list identifier */
 hid_t     space_id;    /* space handle */
 hsize_t   dimsf[RANK]; /* dataset dimensions */
 herr_t    status; 
 int       i, j, k;
	int       imax,jmax,kmax;
	float     valex,xmin,xmax,value;
 FILE      *f;
	
 /* HDF Explorer shows by default, in the map display 
	dim[0] = Depth
	dim[1] = Vertical
	dim[1] = Horizontal 
	*/
	dimsf[0] = LAYERS;
	dimsf[1] = ROWS;
	dimsf[2] = COLS;

	/* read data */
	
	printf("reading layers\n" );
	f  = fopen( "autmedoo.txt", "r" ) ;
	fscanf( f, "%d %d %d", &imax, &jmax, &kmax ); 
	fscanf( f, "%f %f %f", &valex, &xmin, &xmax ); 

	//for ( k=kmax-1; k>=0; k-- )
	for ( k=0; k<kmax; k++ )
	{
		printf("%d ",k);
		for ( j=jmax-1; j>=0; j-- ) 
			for ( i=0; i<imax; i++ ) 
			{
				fscanf( f, "%f ", &value ); 
				data[k][j][i] = value;
			}
	}
	
/*
	* Create a new HDF5 file using H5F_ACC_TRUNC access,
	* default file creation properties, and default file
	* access properties.
	*/
	file_id = H5Fcreate("modb.h5", H5F_ACC_TRUNC, H5P_DEFAULT, H5P_DEFAULT );
	
/*
	* Create property list for a dataset and set up fill values.
	*/
	plist = H5Pcreate(H5P_DATASET_CREATE);
	status = H5Pset_fill_value( plist, H5T_NATIVE_FLOAT, &valex );
	
	
/*
	* Describe the size of the array and create the data space for fixed
	* size dataset. 
	*/
	space_id = H5Screate_simple(RANK, dimsf, NULL); 
	
/*
	* Create dataset in the file. Notice that creation
	* property list plist is used.
	*/
	dset_id = H5Dcreate(file_id, "autmedoo", H5T_NATIVE_FLOAT, space_id, plist);
		
/*
	* Write the data to the dataset using default transfer properties.
	*/
	status = H5Dwrite(dset_id, H5T_NATIVE_FLOAT, H5S_ALL, H5S_ALL,H5P_DEFAULT, data);
	
	/*
	* Close/release resources.
	*/
	H5Sclose(space_id);
	H5Dclose(dset_id);
	H5Fclose(file_id);
		
	
	return 0;
}     
/*
!The first line of the ASCII file contains the dimension of the array : 
! IMAX, JMAX, KMAX. The integers are stored with the FORTRAN format I5. 
!The second line contains the exclusion value, the minimum and the maximum value of this 
! file. These numbers are stored with the FORTRAN format E12.5. 
! The remaining lines contains the data of the array, with 5 numbers per line 
! (except the last line for each I-line). 
! The array is stored in horizontal slices from sea surface to sea bottom and from 
! north to south. So the indexes go from : 
!
!   DO K = KMAX to 1
!       DO J = JMAX to 1
!           DO I = 1 to IMAX
!              read
!           OD
!       OD
!   OD
! 
!              ____________________________
!             /                           /| (imax,jmax,kmax)
!            /        sea surface        / |
!           /                           /  |
!          /__________________________ /   |
!          |                          |    |
!          |                          |    | (imax,jmax,1)        n
!          |                          |   /                      /
!          |                          |  /                      /
!     ^  j |                          | /             w  <-----o-----> e
!  k  |  / |__________________________|/                      /
!     | /                           (imax,1,1)               /
!     |---------->                                          s
!	    i
!
!
!
!
*/

